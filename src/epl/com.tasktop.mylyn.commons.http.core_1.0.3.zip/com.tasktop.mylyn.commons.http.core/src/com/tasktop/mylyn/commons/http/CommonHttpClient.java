/*******************************************************************************
 * Copyright (c) 2010 Tasktop Technologies and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Tasktop Technologies - initial API and implementation
 *******************************************************************************/

package com.tasktop.mylyn.commons.http;

import static com.tasktop.mylyn.commons.core.util.CommonsNetConverter.fromCommonsNet;
import static com.tasktop.mylyn.commons.core.util.CommonsNetConverter.toCommonsNet;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.impl.auth.DigestScheme;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpProtocolParams;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.mylyn.commons.core.operations.IOperationMonitor;
import org.eclipse.mylyn.commons.core.operations.IOperationMonitor.OperationFlag;
import org.eclipse.mylyn.commons.net.AbstractWebLocation;
import org.eclipse.mylyn.commons.net.UnsupportedRequestException;
import org.eclipse.mylyn.commons.net.WebUtil;
import org.eclipse.mylyn.commons.repositories.core.RepositoryLocation;
import org.eclipse.mylyn.commons.repositories.core.auth.AuthenticationCredentials;
import org.eclipse.mylyn.commons.repositories.core.auth.AuthenticationType;
import org.eclipse.mylyn.commons.repositories.http.core.HttpUtil;
import org.eclipse.mylyn.internal.tasks.core.TaskRepositoryLocation;
import org.eclipse.mylyn.tasks.core.TaskRepository;
import org.eclipse.osgi.util.NLS;

import com.tasktop.mylyn.commons.core.util.ProgressUtil;

/**
 * Facilitates connections to repositories accessed through Http.
 * 
 * @author Steffen Pingel
 * @author Shawn Minto
 * @author Sam Davis
 */
public class CommonHttpClient {

	private static final String DEFAULT_USER_AGENT = "Apache XML-RPC/3.0"; //$NON-NLS-1$

	private final org.eclipse.mylyn.commons.repositories.http.core.CommonHttpClient delegate;

	private static AbstractHttpClient createHttpClient(String userAgent) {
		DefaultHttpClient httpClient = new DefaultHttpClient(HttpUtil.getConnectionManager());
		HttpUtil.configureClient(httpClient, WebUtil.getUserAgent(userAgent));
		HttpClientParams.setCookiePolicy(httpClient.getParams(), CookiePolicy.RFC_2109);
		HttpProtocolParams.setUseExpectContinue(httpClient.getParams(), false);
		return httpClient;
	}

	volatile DigestScheme digestScheme;

	final AbstractHttpClient httpClient;

	private final RepositoryLocation location;

	private final AbstractWebLocation webLocation;

	public CommonHttpClient(final AbstractWebLocation webLocation) {
		this.webLocation = webLocation;
		location = new RepositoryLocation(webLocation.getUrl()) {
			@Override
			public String getProperty(String name) {
				if (webLocation instanceof TaskRepositoryLocation) {
					// use TaskRepository proxy info
					TaskRepository taskRepository = ((TaskRepositoryLocation) webLocation).getTaskRepository();
					if (PROPERTY_PROXY_USEDEFAULT.equals(name)) {
						return taskRepository.getProperty(TaskRepository.PROXY_USEDEFAULT);
					} else if (PROPERTY_PROXY_HOST.equals(name)) {
						return taskRepository.getProperty(TaskRepository.PROXY_HOSTNAME);
					} else if (PROPERTY_PROXY_PORT.equals(name)) {
						return taskRepository.getProperty(TaskRepository.PROXY_PORT);
					}
				}
				return super.getProperty(name);
			}

			@Override
			public <T extends AuthenticationCredentials> T getCredentials(AuthenticationType<T> authType,
					boolean loadSecrets) {
				return fromCommonsNet(webLocation.getCredentials(toCommonsNet(authType)), authType.getCredentialsType());
			}
		};
		this.httpClient = createHttpClient(DEFAULT_USER_AGENT);
		delegate = new org.eclipse.mylyn.commons.repositories.http.core.CommonHttpClient(location) {
			@Override
			protected AbstractHttpClient createHttpClient(String userAgent) {
				return httpClient;
			}
		};
		delegate.setHttpAuthenticationType(AuthenticationType.REPOSITORY);
	}

	public AbstractHttpClient getHttpClient() {
		return httpClient;
	}

	public AbstractWebLocation getLocation() {
		return webLocation;
	}

	public HttpResponse execute(HttpRequestBase method, IOperationMonitor monitor) throws IOException {
		return delegate.execute(method, monitor);
	}

	protected boolean authenticate(IOperationMonitor monitor) throws IOException {
		return true;
	}

	protected AuthenticationType<?> needsReauthentication(int code, IProgressMonitor monitor) throws IOException {
		if (code == HttpStatus.SC_UNAUTHORIZED || code == HttpStatus.SC_FORBIDDEN) {
			return AuthenticationType.HTTP;
		} else if (code == HttpStatus.SC_PROXY_AUTHENTICATION_REQUIRED) {
			return AuthenticationType.PROXY;
		}
		return null;
	}

	/**
	 * @param authenticationType
	 * @param code
	 *            status code that prompted reauthentication
	 * @param monitor
	 * @throws IOException
	 */
	protected void reauthenticate(AuthenticationType<?> authenticationType, int code, IProgressMonitor monitor)
			throws IOException {
		IOperationMonitor operationMonitor = ProgressUtil.convert(monitor);
		if (!authenticate(operationMonitor)) {
			requestCredentials(authenticationType, code, operationMonitor);
			authenticate(operationMonitor);
		}
	}

	protected void requestCredentials(final AuthenticationType<?> authType, int code, IProgressMonitor monitor)
			throws IOException {
		try {
			if (monitor instanceof IOperationMonitor) {
				if (((IOperationMonitor) monitor).hasFlag(OperationFlag.BACKGROUND)) {
					throw new UnsupportedOperationException();
				}
			}

			webLocation.requestCredentials(toCommonsNet(authType), null, monitor);
		} catch (UnsupportedRequestException e) {
			IOException ioe = new IOException(NLS.bind(Messages.CommonHttpClient_X_Y, code,
					HttpUtil.getStatusText(code)));
			ioe.initCause(e);
			throw ioe;
		} catch (UnsupportedOperationException e) {
			IOException ioe = new IOException(NLS.bind(Messages.CommonHttpClient_X_Y, code,
					HttpUtil.getStatusText(code)));
			ioe.initCause(e);
			throw ioe;
		}
	}

	public void setAuthenticationPreemptive(boolean enabled) {
		delegate.setPreemptiveAuthenticationEnabled(enabled);
	}

}