/*******************************************************************************
 * Copyright (c) 2004, 2014 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.mylyn.commons.core.util;

import org.eclipse.mylyn.commons.repositories.core.auth.AuthenticationCredentials;
import org.eclipse.mylyn.commons.repositories.core.auth.AuthenticationType;
import org.eclipse.mylyn.commons.repositories.core.auth.UserCredentials;

public class CommonsNetConverter {
	@SuppressWarnings("unchecked")
	public static <T extends AuthenticationCredentials> T fromCommonsNet(
			org.eclipse.mylyn.commons.net.AuthenticationCredentials credentials, Class<T> clazz) {
		if (credentials == null) {
			return null;
		}
		if (clazz == UserCredentials.class) {
			return (T) new UserCredentials(credentials.getUserName(), credentials.getPassword());
		}
		throw new RuntimeException("Unsupported credentials type " + clazz.getName()); //$NON-NLS-1$

	}

	public static org.eclipse.mylyn.commons.net.AuthenticationCredentials toCommonsNet(
			AuthenticationCredentials credentials) {
		if (credentials == null) {
			return null;
		}
		if (credentials instanceof UserCredentials) {
			UserCredentials userCredentials = (UserCredentials) credentials;
			return new org.eclipse.mylyn.commons.net.AuthenticationCredentials(userCredentials.getUserName(),
					userCredentials.getPassword());
		}
		throw new RuntimeException("Unsupported credentials type " + credentials.getClass().getName()); //$NON-NLS-1$
	}

	public static org.eclipse.mylyn.commons.net.AuthenticationType toCommonsNet(
			final AuthenticationType<?> authenticationType) {
		if (authenticationType == AuthenticationType.HTTP) {
			return org.eclipse.mylyn.commons.net.AuthenticationType.HTTP;
		} else if (authenticationType == AuthenticationType.REPOSITORY) {
			return org.eclipse.mylyn.commons.net.AuthenticationType.REPOSITORY;
		} else if (authenticationType == AuthenticationType.PROXY) {
			return org.eclipse.mylyn.commons.net.AuthenticationType.PROXY;
		} else if (authenticationType == AuthenticationType.CERTIFICATE) {
			return org.eclipse.mylyn.commons.net.AuthenticationType.CERTIFICATE;
		}
		throw new RuntimeException("Unsupported authentication type " + authenticationType); //$NON-NLS-1$
	}
}
