package com.tasktop.mylyn.commons.http;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.http.entity.mime.MIME;
import org.apache.http.entity.mime.content.AbstractContentBody;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.mylyn.commons.core.operations.IOperationMonitor;
import org.eclipse.mylyn.tasks.core.data.AbstractTaskAttachmentSource;

/**
 * Opens a new input stream each time {@link #writeTo(OutputStream)} is called so that the request can be repeated if
 * there is an auth failure (e.g. 407 with NTLM) or IO error. This is the same behaviour as when using FilePart from
 * Apache client 3.1 with TaskAttachmentPartSource.
 * 
 * @author Sam Davis
 */
public class RepeatableAttachmentContentBody extends AbstractContentBody {
	private final AbstractTaskAttachmentSource source;

	private final IOperationMonitor monitor;

	public RepeatableAttachmentContentBody(String mimeType, AbstractTaskAttachmentSource source,
			IOperationMonitor monitor) {
		super(mimeType);
		this.source = source;
		this.monitor = monitor;
	}

	public void writeTo(OutputStream out) throws IOException {
		InputStream in = null;
		try {
			in = source.createInputStream(monitor);
			IOUtils.copy(in, out);
		} catch (CoreException e) {
			throw new RuntimeException(e);
		} finally {
			if (in != null) {
				in.close();
			}
		}
	}

	public long getContentLength() {
		return source.getLength();
	}

	public String getFilename() {
		return source.getName();
	}

	public String getCharset() {
		return null;
	}

	public String getTransferEncoding() {
		return MIME.ENC_BINARY;
	}
}