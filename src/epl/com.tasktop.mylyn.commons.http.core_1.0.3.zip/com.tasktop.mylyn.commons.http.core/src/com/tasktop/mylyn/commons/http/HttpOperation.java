/*******************************************************************************
 * Copyright (c) 2010 Tasktop Technologies and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Tasktop Technologies - initial API and implementation
 *     Eike Stepper - fixes for bug 323568
 *******************************************************************************/

package com.tasktop.mylyn.commons.http;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpRequestBase;
import org.eclipse.mylyn.commons.core.operations.IOperationMonitor;
import org.eclipse.mylyn.commons.repositories.core.auth.AuthenticationCredentials;
import org.eclipse.mylyn.commons.repositories.core.auth.AuthenticationType;
import org.eclipse.mylyn.commons.repositories.http.core.HttpUtil;

import com.tasktop.mylyn.commons.core.util.ProgressUtil;
import com.tasktop.mylyn.internal.commons.http.CommonDeleteMethod;
import com.tasktop.mylyn.internal.commons.http.CommonGetMethod;
import com.tasktop.mylyn.internal.commons.http.CommonHeadMethod;
import com.tasktop.mylyn.internal.commons.http.CommonPostMethod;
import com.tasktop.mylyn.internal.commons.http.CommonPutMethod;

/**
 * @author Steffen Pingel
 * @author Shawn Minto
 * @author Sam Davis
 */
public abstract class HttpOperation<T> {

	private final CommonHttpClient client;

	public HttpOperation(CommonHttpClient client) {
		this.client = client;
	}

	protected CommonGetMethod createGetMethod(String requestPath) {
		return new CommonGetMethod(requestPath);
	}

	protected CommonPostMethod createPostMethod(String requestPath) {
		return new CommonPostMethod(requestPath);
	}

	protected CommonPutMethod createPutMethod(String requestPath) {
		return new CommonPutMethod(requestPath);
	}

	protected CommonDeleteMethod createDeleteMethod(String requestPath) {
		return new CommonDeleteMethod(requestPath);
	}

	protected CommonHeadMethod createHeadMethod(String requestPath) {
		return new CommonHeadMethod(requestPath);
	}

	protected int execute(CommonHttpMethod method, IOperationMonitor monitor) throws IOException {
		return execute(method, java.net.HttpURLConnection.HTTP_OK, monitor);
	}

	protected int execute(CommonHttpMethod commonMethod, int okStatus, IOperationMonitor monitor) throws IOException {
		monitor = ProgressUtil.convert(monitor);
		HttpRequestBase method = commonMethod.getRequest();

		if (commonMethod.isGzipAccepted()) {
			method.setHeader(CommonHttpMethod.ACCEPT_ENCODING, CommonHttpMethod.CONTENT_ENCODING_GZIP);
		}

		if (needsAuthentication()) {
			client.authenticate(monitor);
		}

		Debug.logHttpMethodIfEnabled(method);

		HttpResponse response = executeOnce(method, monitor);
		commonMethod.setResponse(response);
		int statusCode = commonMethod.getStatusCode();

		Debug.logHttpReturnCodeIfEnabled(statusCode);

		if (statusCode == okStatus) {
			return statusCode;
		} else {
			AuthenticationType<?> authenticationType = needsReauthentication(statusCode, monitor);
			if (authenticationType != null) {
				HttpUtil.release(method, response, monitor);
				reauthenticate(authenticationType, statusCode, monitor);
				response = executeOnce(method, monitor);
				commonMethod.setResponse(response);
			}
			return commonMethod.getStatusCode();
		}
	}

	private HttpResponse executeOnce(HttpRequestBase method, IOperationMonitor monitor) throws IOException {
		return client.execute(method, monitor);
	}

	protected final CommonHttpClient getClient() {
		return client;
	}

	protected boolean hasCredentials(AuthenticationCredentials credentials) {
		return credentials != null;
	}

	protected boolean needsAuthentication() {
		return false;
	}

	protected AuthenticationType<?> needsReauthentication(int code, IOperationMonitor monitor) throws IOException {
		return client.needsReauthentication(code, monitor);
	}

	protected void reauthenticate(AuthenticationType<?> authenticationType, int code, IOperationMonitor monitor)
			throws IOException {
		client.reauthenticate(authenticationType, code, monitor);
	}

}
