/*******************************************************************************
 * Copyright (c) 2010 Tasktop Technologies and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Tasktop Technologies - initial API and implementation
 *******************************************************************************/

package com.tasktop.mylyn.commons.core.util;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.mylyn.commons.core.operations.IOperationMonitor;
import org.eclipse.mylyn.commons.core.operations.IOperationMonitor.OperationFlag;
import org.eclipse.mylyn.commons.core.operations.OperationUtil;

/**
 * @author Shawn Minto
 * @author Sam Davis
 */
public class ProgressUtil {

	public static IOperationMonitor convert(IProgressMonitor monitor) {
		return addFlags(monitor, OperationUtil.convert(monitor));
	}

	public static IOperationMonitor convert(IProgressMonitor monitor, int work) {
		return addFlags(monitor, OperationUtil.convert(monitor, work));
	}

	public static IOperationMonitor convert(IProgressMonitor monitor, String taskName, int work) {
		return addFlags(monitor, OperationUtil.convert(monitor, taskName, work));
	}

	private static IOperationMonitor addFlags(IProgressMonitor monitor, IOperationMonitor operationMonitor) {
		if (OperationUtil.isBackgroundMonitor(monitor)) {
			operationMonitor.addFlag(OperationFlag.BACKGROUND);
		}
		return operationMonitor;
	}
}
