/*******************************************************************************
 * Copyright (c) 2013 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.mylyn.commons.http;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.apache.http.client.methods.HttpRequestBase;
import org.eclipse.core.runtime.Platform;
import org.eclipse.mylyn.commons.repositories.http.core.HttpUtil;

public class Debug {
	static final boolean DEBUG = Boolean.valueOf(Platform.getDebugOption("com.tasktop.mylyn.commons.http.core/debug")); //$NON-NLS-1$

	static boolean isEnabled() {
		return DEBUG;
	}

	public static void logHttpMethodIfEnabled(HttpRequestBase method) {
		try {
			if (Debug.isEnabled()) {
				System.out.println(">> " + method.getMethod() + " " + URLDecoder.decode(method.getURI().toString(), "UTF-8")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	public static void logHttpReturnCodeIfEnabled(int code) {
		if (Debug.isEnabled()) {
			System.out.println("<< " + HttpUtil.getStatusText(code) + " (" + code + ")"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		}
	}
}
