package com.tasktop.ui.application;

import java.util.ArrayList;

import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileInfo;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;

public class OpenFileHandler implements Listener {

	private final ArrayList files = new ArrayList(1);

	public OpenFileHandler(Display display) {
		// SWT.OpenDocument
		display.addListener(46, this);
	}

	public void handleEvent(Event event) {
		final String path = event.text;
		if (path == null) {
			return;
		}
		synchronized (files) {
			files.add(path);
		}
	}

	/**
	 * Process delayed events.
	 * 
	 * @param display
	 *            display associated with the workbench
	 */
	public void openFiles(Display display) {
		String[] paths = null;
		synchronized (files) {
			paths = (String[]) files.toArray(new String[files.size()]);
			files.clear();
		}

		if (paths != null) {
			for (String path : paths) {
				openFile(display, path);
			}
		}
	}

	private void openFile(Display display, final String path) {
		display.asyncExec(new Runnable() {
			public void run() {
				IWorkbenchWindow window = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
				if (window == null) {
					return;
				}

				processPath(path, window);
			}
		});
	}

	protected void processPath(final String path, IWorkbenchWindow window) {
		if (path != null && "FORCE_ACTIVE".equals(path)) {
			Shell windowShell = window.getShell();
			if (windowShell != null && !windowShell.isDisposed()) {
				if (windowShell != null) {
					windowShell.open();
					if (windowShell.getMinimized()) {
						windowShell.setMinimized(false);
					}
					if (!windowShell.getVisible()) {
						windowShell.setVisible(true);
					}
					windowShell.forceActive();
					windowShell.forceFocus();
				}
			}
			return;
		}

		if (path != null && "SHUTDOWN".equals(path)) {
			if (TasktopApplicationPlugin.getDefault() != null) {
				ILog log = TasktopApplicationPlugin.getDefault().getLog();
				log.log(new Status(IStatus.INFO, TasktopApplicationPlugin.PLUGIN_ID,
						"SHUTDOWN Signal Received.  Shutting down workbench."));
			}
			PlatformUI.getWorkbench().close();
			return;
		}

		IFileStore efs = EFS.getLocalFileSystem().getStore(new Path(path));
		IFileInfo fileInfo = efs.fetchInfo();
		if (!fileInfo.isDirectory() && fileInfo.exists()) {
			IWorkbenchPage page = window.getActivePage();
			try {
				IDE.openEditorOnFileStore(page, efs);
			} catch (PartInitException e) {
				// ignore
			}
		}
	}

}
