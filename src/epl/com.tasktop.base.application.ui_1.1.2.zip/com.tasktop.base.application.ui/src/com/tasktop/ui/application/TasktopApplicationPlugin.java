/*******************************************************************************
 * Copyright (c) 2004, 2008 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/
package com.tasktop.ui.application;

import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class TasktopApplicationPlugin extends AbstractUIPlugin {

	public static final String PLUGIN_ID = "com.tasktop.base.application.ui";

	private static TasktopApplicationPlugin plugin;

	public TasktopApplicationPlugin() {
	}

	
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	public static TasktopApplicationPlugin getDefault() {
		return plugin;
	}

}
