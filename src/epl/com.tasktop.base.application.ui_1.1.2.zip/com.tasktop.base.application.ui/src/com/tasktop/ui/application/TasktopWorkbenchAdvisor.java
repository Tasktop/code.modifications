/*******************************************************************************
 * Copyright (c) 2004, 2008 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.ui.application;

import java.util.Arrays;
import java.util.List;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.preferences.DefaultScope;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IScopeContext;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbenchPreferenceConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;
import org.eclipse.ui.internal.UIPlugin;

/**
 * @author Mik Kersten
 */
public class TasktopWorkbenchAdvisor extends GenericWorkbenchAdvisor {

//	private static final String PERSPECTIVE_ID = "com.tasktop.ui.perspectives.working";

	private static final String PREF_REFRESH_ENABLED = "com.tasktop.resources.refresh.enabled";

	private final OpenFileHandler openFileHandler;

	public TasktopWorkbenchAdvisor(OpenFileHandler processor) {
		this.openFileHandler = processor;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.application.WorkbenchAdvisor#eventLoopIdle(org.eclipse.swt.widgets.Display)
	 */
	public void eventLoopIdle(Display display) {
		try {
			if (openFileHandler != null)
				openFileHandler.openFiles(display);
		} catch (Throwable t) {
			// ignore any errors from this.
		}
		super.eventLoopIdle(display);
	}

	public WorkbenchWindowAdvisor createWorkbenchWindowAdvisor(IWorkbenchWindowConfigurer configurer) {
		initDefaultPrefs();
		return new TasktopWorkbenchWindowAdvisor(this, configurer);
	}

	public boolean openWindows() {
		// ignore
		boolean opened = super.openWindows();

		try {
			boolean shouldHideOnStart = false;
			List commandLineArgs = Arrays.asList(Platform.getCommandLineArgs());
			if (commandLineArgs.contains("-tasktop-hidden")) {
				shouldHideOnStart = true;
			}
			if (shouldHideOnStart) {
				IWorkbenchWindow[] workbenchWindows = PlatformUI.getWorkbench().getWorkbenchWindows();
				for (int i = 0; i < workbenchWindows.length; i++) {
					workbenchWindows[i].getShell().setVisible(false);
				}
			}
		} catch (Throwable t) {
			// ignore
		}

		return opened;
	}

	protected void initDefaultPrefs() {
		IScopeContext context = new DefaultScope();
		IEclipsePreferences uiNode = context.getNode(UIPlugin.getDefault().getBundle().getSymbolicName());
		uiNode.putBoolean(IWorkbenchPreferenceConstants.SHOW_TRADITIONAL_STYLE_TABS, false);
		uiNode.put(IWorkbenchPreferenceConstants.DOCK_PERSPECTIVE_BAR, IWorkbenchPreferenceConstants.TOP_RIGHT);
		uiNode.putBoolean(IWorkbenchPreferenceConstants.LINK_NAVIGATOR_TO_EDITOR, true);

		// IEclipsePreferences workbenchNode =
		// context.getNode(WorkbenchPlugin.getDefault().getBundle().getSymbolicName());
		// workbenchNode.putBoolean(IPreferenceConstants.OPEN_ON_SINGLE_CLICK,
		// true);

		if (!ResourcesPlugin.getPlugin().getPluginPreferences().getBoolean(PREF_REFRESH_ENABLED)) {
			ResourcesPlugin.getPlugin().getPluginPreferences().setValue(ResourcesPlugin.PREF_AUTO_REFRESH, true);
			ResourcesPlugin.getPlugin().getPluginPreferences().setValue(PREF_REFRESH_ENABLED, true);
			ResourcesPlugin.getPlugin().savePluginPreferences();
		}

	}

	public String getInitialWindowPerspectiveId() {
		return "com.tasktop.client.ui.perspectives.working";//WorkingPerspectiveFactory.ID_PERSPECTIVE;
	}

}
