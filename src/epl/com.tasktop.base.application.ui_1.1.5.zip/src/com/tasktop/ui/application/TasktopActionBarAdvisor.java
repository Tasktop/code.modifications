/*******************************************************************************
 * Copyright (c) 2004, 2008 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.ui.application;

//import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.ToolBarContributionItem;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.ide.IIDEActionConstants;
import org.eclipse.ui.internal.provisional.application.IActionBarConfigurer2;

/**
 * @author Mik Kersten
 * @author Terry Hon
 */
public class TasktopActionBarAdvisor extends GenericActionBuilder {

//	private MainTabPulldownAction mainTabPulldownAction;
//	private PasteTabPulldownAction copyTabPulldownAction;
//	Action openTasktopPreferencesAction;
//	private int flags;
//	private boolean showMenuBar;

	public TasktopActionBarAdvisor(IActionBarConfigurer configurer) {
		super(configurer);
	}

	
	protected void makeActions(IWorkbenchWindow window) {
		super.makeActions(window);

//		 mainTabPulldownAction = new MainTabPulldownAction(window, this);
//		 register(mainTabPulldownAction);
//		 
//		 openTasktopPreferencesAction = new OpenTasktopPreferencesAction();
//		 register(openTasktopPreferencesAction);
//
//		 copyTabPulldownAction = new PasteTabPulldownAction(this);
//		 register(copyTabPulldownAction);
	}

	/**
	 * Fills the menu bar with the workbench actions.
	 */
	
	protected void fillMenuBar(IMenuManager menuBar) {
		menuBar.add(createFileMenu());
		menuBar.add(createEditMenu());
		menuBar.add(createNavigateMenu());
//		menuBar.add(createProjectMenu());
		menuBar.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
		menuBar.add(createWindowMenu());
		menuBar.add(createHelpMenu());
	}

	
	protected void fillCoolBar(ICoolBarManager coolBar) {
		super.fillCoolBar(coolBar);

//		IToolBarManager toolbar = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
//		coolBar.insertBefore(IIDEActionConstants.GROUP_FILE, new ToolBarContributionItem(toolbar, "main"));
//        toolbar.add(mainTabPulldownAction);
//        
//        IToolBarManager copyToolBar = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
//        coolBar.insertBefore(IIDEActionConstants.GROUP_FILE, new ToolBarContributionItem(copyToolBar, "copy"));
//        toolbar.add(copyTabPulldownAction);        
//
		IActionBarConfigurer2 actionBarConfigurer = (IActionBarConfigurer2) getActionBarConfigurer();
		IToolBarManager tasktopToolbar = actionBarConfigurer.createToolBarManager();
		coolBar.insertBefore(IIDEActionConstants.GROUP_FILE, actionBarConfigurer.createToolBarContributionItem(
				tasktopToolbar, "com.tasktop.ui.actionSet"));

		IToolBarManager copyToolBar = new ToolBarManager(SWT.FLAT | SWT.RIGHT);
		coolBar.insertBefore(IWorkbenchActionConstants.MB_ADDITIONS, new ToolBarContributionItem(copyToolBar, "copy"));
		cutAction.setDisabledImageDescriptor(ImageDescriptor.createWithFlags(cutAction.getImageDescriptor(),
				SWT.IMAGE_GRAY));
		copyAction.setDisabledImageDescriptor(ImageDescriptor.createWithFlags(copyAction.getImageDescriptor(),
				SWT.IMAGE_GRAY));
		pasteAction.setDisabledImageDescriptor(ImageDescriptor.createWithFlags(pasteAction.getImageDescriptor(),
				SWT.IMAGE_GRAY));
		copyToolBar.add(cutAction);
		copyToolBar.add(copyAction);
		copyToolBar.add(pasteAction);
//
//		IContributionItem[] items = tasktopToolbar.getItems();
//		for (int i=0; i<items.length; i++) {
//			System.out.println(items[i].getId());
//		}
	}

//	private class OpenTasktopPreferencesAction extends Action {
//		
//		public OpenTasktopPreferencesAction() {
//			super("Preferences...");
//			setId("tasktop preferences");
//		}
//		
//		public void run() {
//			PreferenceDialog dialog = PreferencesUtil.createPreferenceDialogOn(null, "com.tasktop.ui.preferences", null, null);
//			dialog.open();
//		}
//		 
//	}

//	public void fillActionBars() {
//		fillActionBars(flags);
//	}
//	
//	public void disposePulldownMenu() {
//		mainTabPulldownAction.dispose();
//	}

}
