/*******************************************************************************
 * Copyright (c) 2010 Tasktop Technologies and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Tasktop Technologies - initial API and implementation
 *******************************************************************************/

package com.tasktop.mylyn.commons.http;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.util.zip.GZIPInputStream;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpRequestBase;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.mylyn.commons.repositories.http.core.HttpUtil;

/**
 * @author Steffen Pingel
 * @author Shawn Minto
 * @author Sam Davis
 */
public abstract class CommonHttpMethod {
	public static final String ACCEPT = "Accept"; //$NON-NLS-1$

	public static final String CONTENT_ENCODING = "Content-Encoding"; //$NON-NLS-1$

	public static final String ACCEPT_ENCODING = "Accept-encoding"; //$NON-NLS-1$

	public static final String CONTENT_ENCODING_GZIP = "gzip"; //$NON-NLS-1$

	protected HttpRequestBase request;

	protected HttpResponse response;

	private boolean gzipAccepted = true;

	private boolean gzipReceived;

	private InputStream inputStream;

	private final Object releaseLock = new Object();

	public void setResponse(HttpResponse response) {
		this.response = response;
	}

	public void removeRequestHeader(String header) {
		request.removeHeaders(header);
	}

	public InputStream getResponseBodyAsStream(IProgressMonitor monitor) throws IOException {
		if (inputStream == null) {
			inputStream = HttpUtil.getResponseBodyAsStream(response.getEntity(), monitor);
		}
		gzipReceived = isZippedResponse();
		if (gzipReceived) {
			inputStream = new GZIPInputStream(inputStream);
		}
		return inputStream;
	}

	public boolean isGzipAccepted() {
		return gzipAccepted;
	}

	protected boolean isZippedResponse() {
		// see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=269018
		return response.getFirstHeader(CONTENT_ENCODING) != null
				&& response.getFirstHeader(CONTENT_ENCODING).getValue().equals(CONTENT_ENCODING_GZIP);
	}

	// This override is a workaround for 
	// https://bugs.eclipse.org/bugs/show_bug.cgi?id=279457
	// This makes GetMethod.releaseConnection non-reentrant,
	// as with reentrancy under some circumstances a NPE can be 
	// thrown with multithreaded access
	public void releaseConnection() {
		synchronized (releaseLock) {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					// ignore
				}
				inputStream = null;
			}
			request.releaseConnection();
		}
	}

	public void releaseConnection(IProgressMonitor monitor) {
		if (monitor != null && monitor.isCanceled()) {
			// force a connection close on cancel to avoid blocking to do reading the remainder of the response 
			request.abort();
		} else {
			try {
				request.releaseConnection();
			} catch (NullPointerException e) {
				// ignore, see bug 255417
			}
		}
	}

	public final void setGzipAccepted(boolean gzipAccepted) {
		this.gzipAccepted = gzipAccepted;
	}

	public HttpRequestBase getRequest() {
		return request;
	}

	public HttpResponse getResponse() {
		return response;
	}

	public Object getPath() {
		return request.getURI().getPath();
	}

	public URI getURI() {
		return request.getURI();
	}

	public void setRequestHeader(String name, String value) {
		request.setHeader(name, value);
	}

	public Header getRequestHeader(String name) {
		return request.getFirstHeader(name);
	}

	public Header getResponseHeader(String name) {
		return response.getFirstHeader(name);
	}

	public StatusLine getStatusLine() {
		return response.getStatusLine();
	}

	public int getStatusCode() {
		if (response.getStatusLine() == null) {
			return -1;
		}
		return response.getStatusLine().getStatusCode();
	}
}
