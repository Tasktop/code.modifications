/*******************************************************************************
 * Copyright (c) 2004, 2010 Composent, Inc., IBM All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Eclipse Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors: 
 *  Composent, Inc. - initial API and implementation
 *  Maarten Meijer - bug 237936, added gzip encoded transfer default
 *  Henrich Kraemer - bug 263869, testHttpsReceiveFile fails using HTTP proxy
 *  Henrich Kraemer - bug 263613, [transport] Update site contacting / downloading is not cancelable
 *  Tasktop Technologies - cancellation support for streams
 ******************************************************************************/

package com.tasktop.mylyn.internal.commons.http;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.apache.http.client.methods.HttpGet;

import com.tasktop.mylyn.commons.http.CommonHttpMethod;

/**
 * Based on {@code org.eclipse.ecf.provider.filetransfer.httpclient.HttpClientRetrieveFileTransfer}.
 * 
 * @author Steffen Pingel
 * @author Shawn Minto
 * @author Sam Davis
 */
public class CommonGetMethod extends CommonHttpMethod {

	private Set<String> contentTypesSupportingCompression;

	public CommonGetMethod(String requestPath) {
		request = new HttpGet(requestPath);
	}

	@Override
	public final boolean isGzipAccepted() {
		return super.isGzipAccepted() && contentTypeSupportsCompression();
	}

	private boolean contentTypeSupportsCompression() {
		return contentTypesSupportingCompression == null
				|| (request.getFirstHeader(ACCEPT) != null && contentTypesSupportingCompression.contains(request.getFirstHeader(
						ACCEPT)
						.getValue()));
	}

	public Set<String> getContentTypesSupportingCompression() {
		return contentTypesSupportingCompression;
	}

	public void setContentTypesSupportingCompression(Set<String> contentTypesSupportingCompression) {
		this.contentTypesSupportingCompression = Collections.unmodifiableSet(new HashSet<String>(
				contentTypesSupportingCompression));
	}

	public void setContentTypesSupportingCompression(String... contentTypesSupportingCompression) {
		this.contentTypesSupportingCompression = Collections.unmodifiableSet(new HashSet<String>(
				Arrays.asList(contentTypesSupportingCompression)));
	}
}
