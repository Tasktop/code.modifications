/*******************************************************************************
 * Copyright (c) 2004, 2014 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.mylyn.internal.commons.http;

import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;

import com.tasktop.mylyn.commons.http.CommonHttpMethod;

public abstract class CommonEntityEnclosingMethod extends CommonHttpMethod {

	public void setRequestEntity(HttpEntity entity) {
		((HttpEntityEnclosingRequest) request).setEntity(entity);
	}
}
