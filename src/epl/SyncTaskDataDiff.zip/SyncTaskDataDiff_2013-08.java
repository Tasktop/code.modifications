/*******************************************************************************
 * Copyright (c) 2004, 2009 Tasktop Technologies and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Tasktop Technologies - initial API and implementation
 *******************************************************************************/

package com.tasktop.sync.core.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.runtime.Assert;
import org.eclipse.mylyn.tasks.core.data.TaskAttribute;
import org.eclipse.mylyn.tasks.core.data.TaskData;

/**
 * Copied from Mylyn TaskDataDiff which compares only visible attributes. This version compares all attributes by the
 * values of their options rather than the labels, and is aware of sub-attributes as well. Returns only the id's of the
 * task attributes, and doesn't handle comments.
 */
public class SyncTaskDataDiff {

	private final TaskData newTaskData;

	private final TaskData oldTaskData;

	private final Set<String> changedAttributeIds = new HashSet<String>();

	public SyncTaskDataDiff(TaskData newTaskData, TaskData oldTaskData) {
		Assert.isNotNull(newTaskData);
		this.newTaskData = newTaskData;
		this.oldTaskData = oldTaskData;
		parse();
	}

	public Set<String> getChangedAttributeIds() {
		return Collections.unmodifiableSet(changedAttributeIds);
	}

	private void parse() {
		// other attributes that have changed on newTaskData
		for (TaskAttribute newAttribute : newTaskData.getRoot().getAttributes().values()) {
			TaskAttribute oldAttribute = null;
			if (oldTaskData != null) {
				oldAttribute = oldTaskData.getRoot().getMappedAttribute(newAttribute.getPath());
			}
			addChangedAttribute(oldAttribute, newAttribute, true);
		}
		// other attributes that have been removed from newTaskData
		if (oldTaskData != null) {
			for (TaskAttribute oldAttribute : oldTaskData.getRoot().getAttributes().values()) {
				TaskAttribute newAttribute = newTaskData.getRoot().getMappedAttribute(oldAttribute.getPath());
				if (newAttribute == null) {
					addChangedAttribute(oldAttribute, newAttribute, true);
				}
			}
		}
	}

	private void addChangedAttribute(TaskAttribute oldAttribute, TaskAttribute newAttribute, boolean ignoreKind) {
		Assert.isTrue(oldAttribute != null || newAttribute != null, "Cannot compare two null attributes");
		TaskAttribute attribute;
		if (newAttribute != null) {
			attribute = newAttribute;
		} else {
			attribute = oldAttribute;
		}
		@SuppressWarnings("null")
		// the above assert guards against NPE
		String type = attribute.getMetaData().getType();
		if (TaskAttribute.TYPE_COMMENT.equals(type)) {
			// we don't handle comment changes in here
		} else if (ignoreKind || attribute.getMetaData().getKind() != null) {
			if (attributesAreDifferent(oldAttribute, newAttribute)) {
				changedAttributeIds.add(attribute.getId());
			}
		}
	}

	/**
	 * Recursively checks whether two attributes are different, comparing values as well as sub-attributes and their
	 * values. If either <code>oldAttribute</code> or <code>newAttribute</code> are null, returns <code>true</code>
	 */
	public static boolean attributesAreDifferent(TaskAttribute oldAttribute, TaskAttribute newAttribute) {
		if (oldAttribute == null || newAttribute == null) {
			return true;
		}
		List<String> oldValues = new ArrayList<String>(oldAttribute.getValues());
		List<String> newValues = new ArrayList<String>(newAttribute.getValues());
		if (!oldValues.equals(newValues)) {
			return true;
		}
		Collection<TaskAttribute> oldChildren = oldAttribute.getAttributes().values();
		Collection<TaskAttribute> newChildren = newAttribute.getAttributes().values();
		if (oldChildren.size() != newChildren.size()) {
			return true;
		}
		for (TaskAttribute newChild : newChildren) {
			TaskAttribute matchingOldChild = oldAttribute.getAttribute(newChild.getId());
			if (matchingOldChild == null) {
				return true;
			}
			if (attributesAreDifferent(matchingOldChild, newChild)) {
				return true;
			}
		}
		return false;
	}

}
