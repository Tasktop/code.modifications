/*******************************************************************************
 * Copyright (c) 2013 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.epl.commons.core;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS {
	private static final String BUNDLE_NAME = "com.tasktop.epl.commons.core.messages"; //$NON-NLS-1$

	public static String DefaultTasktopTaskSchema_time_worked_duration;

	public static String DefaultTasktopTaskSchema_time_worked_id;

	public static String DefaultTasktopTaskSchema_time_worked_start;

	public static String DefaultTasktopTaskSchema_time_worked_user;

	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	private Messages() {
	}
}
