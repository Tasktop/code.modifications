/*******************************************************************************
 * Copyright (c) 2013 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.epl.commons.core;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.eclipse.core.runtime.Assert;
import org.eclipse.mylyn.tasks.core.data.AbstractTaskSchema;
import org.eclipse.mylyn.tasks.core.data.TaskAttribute;
import org.eclipse.mylyn.tasks.core.data.TaskData;

public class DefaultTasktopTaskSchema extends AbstractTaskSchema {
	private static final DefaultTasktopTaskSchema instance = new DefaultTasktopTaskSchema();

	public static Field getField(String taskKey) {
		return instance.getFieldByKey(taskKey);
	}

	public static DefaultTasktopTaskSchema getInstance() {
		return instance;
	}

	public final Field TIMEWORKED_ID = createField(TasktopEplTaskAttribute.TIMEWORKED_ID,
			Messages.DefaultTasktopTaskSchema_time_worked_id, TaskAttribute.TYPE_SHORT_TEXT, Flag.READ_ONLY);

	public final Field TIMEWORKED_USER = createField(TasktopEplTaskAttribute.TIMEWORKED_USER,
			Messages.DefaultTasktopTaskSchema_time_worked_user, TaskAttribute.TYPE_PERSON, Flag.ATTRIBUTE);

	public final Field TIMEWORKED_START_TIMESTAMP = createField(TasktopEplTaskAttribute.TIMEWORKED_START_TIMESTAMP,
			Messages.DefaultTasktopTaskSchema_time_worked_start, TaskAttribute.TYPE_DATETIME, Flag.ATTRIBUTE);

	public final Field TIMEWORKED_DURATION_MS = createField(TasktopEplTaskAttribute.TIMEWORKED_DURATION_MS,
			Messages.DefaultTasktopTaskSchema_time_worked_duration, TaskAttribute.TYPE_LONG, Flag.ATTRIBUTE);

	public static TaskAttribute createWorklogAttribute(int ordinal, String id, String userId, long start,
			long duration, TaskAttribute parent) {
		return createWorklogAttribute(ordinal, new TimeWorkedMapper(id, userId, start, duration), parent);
	}

	public static TaskAttribute createWorklogAttribute(int ordinal, TimeWorkedMapper timeWorked, TaskAttribute parent) {
		TaskAttribute attribute = parent.createMappedAttribute(TasktopEplTaskAttribute.PREFIX_TIMEWORKED
				+ String.valueOf(ordinal));
		timeWorked.applyTo(attribute);
		return attribute;
	}

	public static List<TimeWorkedMapper> getTimeWorkedEntries(TaskData data) {
		Assert.isNotNull(data);
		List<TaskAttribute> timeWorkedAttributes = data.getAttributeMapper().getAttributesByType(data,
				TasktopEplTaskAttribute.TYPE_TIMEWORKED);
		List<TimeWorkedMapper> timeWorkedEntries = new ArrayList<TimeWorkedMapper>();
		for (TaskAttribute timeWorkedAttribute : timeWorkedAttributes) {
			CollectionUtils.addIgnoreNull(timeWorkedEntries, TimeWorkedMapper.createFrom(timeWorkedAttribute));
		}
		return timeWorkedEntries;
	}
}
