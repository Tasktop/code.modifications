/*******************************************************************************
 * Copyright (c) 2013 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.epl.commons.core;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.eclipse.core.runtime.Assert;
import org.eclipse.mylyn.tasks.core.data.TaskAttribute;
import org.eclipse.mylyn.tasks.core.data.TaskAttributeMapper;
import org.eclipse.mylyn.tasks.core.data.TaskData;
import org.eclipse.osgi.util.NLS;

public class TimeWorkedMapper {

	private final String id;

	private final String userId;

	private final long start;

	private final long duration;

	public TimeWorkedMapper(String id, String userId, long start, long duration) {
		this.id = id;
		this.userId = userId;
		this.start = start;
		this.duration = duration;
	}

	public static TimeWorkedMapper createFrom(TaskAttribute attribute) {
		Assert.isNotNull(attribute);

		String id = getStringFromAttribute(attribute, TasktopEplTaskAttribute.TIMEWORKED_ID);
		String userId = getStringFromAttribute(attribute, TasktopEplTaskAttribute.TIMEWORKED_USER);
		long start = getLongFromAttribute(attribute, TasktopEplTaskAttribute.TIMEWORKED_START_TIMESTAMP);
		long duration = getLongFromAttribute(attribute, TasktopEplTaskAttribute.TIMEWORKED_DURATION_MS);

		if (userId != null && start >= 0 && duration >= 0) {
			return new TimeWorkedMapper(id, userId, start, duration);
		}

		return null;
	}

	private static String getStringFromAttribute(TaskAttribute parent, String attributeId) {
		TaskAttribute attribute = parent.getAttribute(attributeId);
		if (attribute != null && StringUtils.isNotBlank(attribute.getValue())) {
			return attribute.getValue();
		}
		return null;
	}

	private static long getLongFromAttribute(TaskAttribute parent, String attributeId) {
		TaskAttribute attribute = parent.getAttribute(attributeId);
		if (attribute != null && NumberUtils.toLong(attribute.getValue()) >= 0) {
			return NumberUtils.toLong(attribute.getValue());
		}
		return -1;
	}

	public void applyTo(TaskAttribute attribute) {
		Assert.isNotNull(attribute);
		TaskData taskData = attribute.getTaskData();
		TaskAttributeMapper mapper = taskData.getAttributeMapper();
		attribute.getMetaData().defaults().setType(TasktopEplTaskAttribute.TYPE_TIMEWORKED);
		if (getId() != null) {
			TaskAttribute child = DefaultTasktopTaskSchema.getField(TasktopEplTaskAttribute.TIMEWORKED_ID)
					.createAttribute(attribute);
			mapper.setValue(child, getId());
		}
		if (getUserId() != null) {
			TaskAttribute child = DefaultTasktopTaskSchema.getField(TasktopEplTaskAttribute.TIMEWORKED_USER)
					.createAttribute(attribute);
			mapper.setValue(child, getUserId());
		}
		if (getStart() > 0) {
			TaskAttribute child = DefaultTasktopTaskSchema.getField(TasktopEplTaskAttribute.TIMEWORKED_START_TIMESTAMP)
					.createAttribute(attribute);
			mapper.setLongValue(child, getStart());
		}
		if (getDuration() >= 0) {
			TaskAttribute child = DefaultTasktopTaskSchema.getField(TasktopEplTaskAttribute.TIMEWORKED_DURATION_MS)
					.createAttribute(attribute);
			mapper.setLongValue(child, getDuration());
		}
	}

	public String getId() {
		return id;
	}

	public String getUserId() {
		return userId;
	}

	public long getStart() {
		return start;
	}

	public long getDuration() {
		return duration;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (duration ^ (duration >>> 32));
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + (int) (start ^ (start >>> 32));
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof TimeWorkedMapper)) {
			return false;
		}
		TimeWorkedMapper other = (TimeWorkedMapper) obj;
		if (duration != other.duration) {
			return false;
		}
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		if (start != other.start) {
			return false;
		}
		if (userId == null) {
			if (other.userId != null) {
				return false;
			}
		} else if (!userId.equals(other.userId)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return NLS.bind("Time Worked[ID: {0}, User: {1}, Start (ms): {2}, Duration (ms): {3}]", new Object[] { getId(), //$NON-NLS-1$
				getUserId(), getStart(), getDuration() });
	}
}
