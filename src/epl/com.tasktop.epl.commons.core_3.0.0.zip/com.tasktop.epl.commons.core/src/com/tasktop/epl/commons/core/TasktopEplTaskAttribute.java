/*******************************************************************************
 * Copyright (c) 2013 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.epl.commons.core;

/**
 * Common task attributes and types
 * 
 * @author tehrnhoefer
 * @noextend This class is not intended to be subclassed by clients.
 * @noinstantiate This class is not intended to be instantiated by clients.
 */
public class TasktopEplTaskAttribute {

	public static final String TYPE_TIMEWORKED = "tasktop.type.timeworked"; //$NON-NLS-1$

	public static final String TIMEWORKED_ID = "com.tasktop.timeworked.id"; //$NON-NLS-1$

	public static final String TIMEWORKED_USER = "com.tasktop.timeworked.user"; //$NON-NLS-1$

	public static final String TIMEWORKED_START_TIMESTAMP = "com.tasktop.timeworked.start"; //$NON-NLS-1$

	public static final String TIMEWORKED_DURATION_MS = "com.tasktop.timeworked.duration"; //$NON-NLS-1$

	public static final String PREFIX_TIMEWORKED = "com.tasktop.timeworked-"; //$NON-NLS-1$

	private TasktopEplTaskAttribute() {
	}
}
