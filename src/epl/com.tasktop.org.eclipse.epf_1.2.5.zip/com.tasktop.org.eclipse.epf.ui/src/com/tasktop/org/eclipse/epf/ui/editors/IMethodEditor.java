package com.tasktop.org.eclipse.epf.ui.editors;

public interface IMethodEditor {

}
