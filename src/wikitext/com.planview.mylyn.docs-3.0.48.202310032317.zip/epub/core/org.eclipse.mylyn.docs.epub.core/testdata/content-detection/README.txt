These files are used by TestEPUBFileUtil to verify that the core media types
are correctly detected. 