This folder contains some very basic EPUB files that are used to verify certain reading mechanisms of the tools. Note
that the EPUB 3 file (basic_3.epub) is not really an EPUB 3, it just pretends to be by specifying this version number
in order for the tools to handle the fact that EPUB 3 is not yet supported.