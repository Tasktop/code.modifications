/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.mylyn.docs.epub.dc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rights</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.mylyn.docs.epub.dc.DCPackage#getRights()
 * @model extendedMetaData="kind='mixed'"
 * @generated
 */
public interface Rights extends LocalizedDCType {
} // Rights
