com.planview.mylyn.docs
=======================

This is a fork of [eclipse-mylyn/org.eclipse.mylyn.docs](https://github.com/eclipse-mylyn/org.eclipse.mylyn.docs).

Below is the original README.md.

org.eclipse.mylyn.docs
======================

Developer resources:
--------------------

Information regarding source code management, builds, coding standards, and more.

- <https://wiki.eclipse.org/Mylyn/Contributor_Reference>


