The contents of this folder is used to test inclusion of content sourced from
an Eclipse table of contents file.