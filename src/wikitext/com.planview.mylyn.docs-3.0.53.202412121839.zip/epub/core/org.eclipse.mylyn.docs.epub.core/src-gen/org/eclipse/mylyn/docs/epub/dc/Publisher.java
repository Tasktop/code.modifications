/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.mylyn.docs.epub.dc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Publisher</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.mylyn.docs.epub.dc.DCPackage#getPublisher()
 * @model extendedMetaData="kind='mixed'"
 * @generated
 */
public interface Publisher extends LocalizedDCType {
} // Publisher
