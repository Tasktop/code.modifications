/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.mylyn.docs.epub.opf;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tours</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.mylyn.docs.epub.opf.OPFPackage#getTours()
 * @model
 * @generated
 */
public interface Tours extends EObject {
} // Tours
