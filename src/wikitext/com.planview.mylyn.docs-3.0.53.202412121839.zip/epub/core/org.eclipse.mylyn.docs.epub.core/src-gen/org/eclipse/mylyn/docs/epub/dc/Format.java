/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.mylyn.docs.epub.dc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Format</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.mylyn.docs.epub.dc.DCPackage#getFormat()
 * @model extendedMetaData="kind='mixed'"
 * @generated
 */
public interface Format extends DCType {
} // Format
