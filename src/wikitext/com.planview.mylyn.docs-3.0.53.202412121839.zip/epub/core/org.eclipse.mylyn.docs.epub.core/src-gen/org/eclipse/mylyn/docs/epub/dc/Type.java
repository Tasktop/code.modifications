/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.mylyn.docs.epub.dc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.mylyn.docs.epub.dc.DCPackage#getType()
 * @model extendedMetaData="kind='mixed'"
 * @generated
 */
public interface Type extends DCType {
} // Type
