/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.mylyn.docs.epub.dc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Coverage</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.mylyn.docs.epub.dc.DCPackage#getCoverage()
 * @model extendedMetaData="kind='mixed'"
 * @generated
 */
public interface Coverage extends LocalizedDCType {
} // Coverage
