# Managed Repository

Please refer to the [GitHub developer enablement documentation](https://tasktop.atlassian.net/wiki/spaces/ENG/pages/2656141428/GitHub+Developer+Enablement+FAQ) for more information on the development workflows.

## Process for Setting Up Locally

1. Clone this repository into your local environment by using the appropriate HTTPS / SSH command.
2. Run the following in the root folder to configure the Git hooks path.

```bash
git config --local core.hooksPath .githooks/
```

3. Ensure the .githooks/ folder is executable by running this command in the root folder.

```bash
chmod +x ./.githooks/*
```

4. Follow the steps below for how to update the repository.

## Process for Updating the Repository

1. Make the necessary changes in your local environment.
2. Create a new feature branch using the command ```git checkout -b <new-branch>```, and push your changes to this branch (attempting to push directly to ```main``` should throw an error and forbid the action).
3. Please ensure you've set up the Git hooks described above, and that you've included the relevant Jira ticket ID in your commit message.
4. In the GitHub UI, create a new PR to merge the feature branch into the main branch.
5. After receiving **at least one approving review** (note that the author of the PR must not be the reviewer), merge the PR into main. Ensure that the merging message includes the relevant Jira ticket ID (ex. does not start with 'Merge pull request...').

## Mend UA Scan customizations

As of `2024-October`, several changes have been made to the Mend UA Scan GitHub action.

From now on, the Mend UA Scan GitHub action will be triggered only when:

- There is a push to `main` or `master` branch
- A PR wants to merge into `main` or `master` branch

In addition, the Mend UA Scan GitHub action now supports custom configurations. To add additional configurations, create a `Mend_UA_scan_custom_config.json` file in the root of the repository.

Example config format:

```json
{
    "WS config 1": "value",
    "WS config 2": "value",
}
```

### Note

The allowed configurations differ between organizations. Please refer to the documentation in [Mend Scans related - Index](https://tasktop.atlassian.net/wiki/x/k4C-2Q) for more information.

For more information about Unified Agent Configuration Parameters, please refer to the [Unified Agent Configuration Parameters documentation](https://docs.mend.io/legacy-sca/latest/unified-agent-configuration-parameters).