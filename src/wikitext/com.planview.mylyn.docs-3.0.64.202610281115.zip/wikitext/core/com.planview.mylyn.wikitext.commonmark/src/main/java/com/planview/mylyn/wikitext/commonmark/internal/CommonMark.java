/*******************************************************************************
 * Copyright (c) 2015 David Green.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v2.0
 * which accompanies this distribution, and is available at
 * https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 * Contributors:
 *     David Green - initial API and implementation
 *******************************************************************************/

package com.planview.mylyn.wikitext.commonmark.internal;

import com.planview.mylyn.wikitext.commonmark.internal.blocks.AtxHeaderBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.BlockQuoteBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.EmptyBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.FencedCodeBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HorizontalRuleBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HtmlBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HtmlCdataBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HtmlCommentBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HtmlDoctypeBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HtmlProcessingInstructionBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HtmlType1Block;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.HtmlType7Block;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.IndentedCodeBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.ListBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.ParagraphBlock;
import com.planview.mylyn.wikitext.commonmark.internal.blocks.SetextHeaderBlock;

public class CommonMark {

	private static final SourceBlocks SOURCE_BLOCKS = new SourceBlocks(new BlockQuoteBlock(), new AtxHeaderBlock(),
			new HorizontalRuleBlock(), new ListBlock(), new SetextHeaderBlock(), new FencedCodeBlock(),
			new IndentedCodeBlock(), new HtmlType1Block(), new HtmlCommentBlock(), new HtmlProcessingInstructionBlock(),
			new HtmlDoctypeBlock(), new HtmlCdataBlock(), new HtmlBlock(), new HtmlType7Block(), new ParagraphBlock(),
			new EmptyBlock());

	public static SourceBlocks sourceBlocks() {
		return SOURCE_BLOCKS;
	}

	private CommonMark() {
		// prevent instantiation
	}
}
