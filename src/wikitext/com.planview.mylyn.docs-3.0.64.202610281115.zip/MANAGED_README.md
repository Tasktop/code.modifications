# Managed Repository

Please refer to the [GitHub developer enablement documentation](https://tasktop.atlassian.net/wiki/spaces/ENG/pages/2656141428/GitHub+Developer+Enablement+FAQ) for more information on the development workflows.

## Process for Setting Up Locally

1. Clone this repository into your local environment by using the appropriate HTTPS / SSH command.
2. Run the following in the root folder to configure the Git hooks path.

```bash
git config --local core.hooksPath .githooks/
```

3. Ensure the .githooks/ folder is executable by running this command in the root folder.

```bash
chmod +x ./.githooks/*
```

4. Follow the steps below for how to update the repository.

## Process for Updating the Repository

1. Make the necessary changes in your local environment.
2. Create a new feature branch using the command ```git checkout -b <new-branch>```, and push your changes to this branch (attempting to push directly to ```main``` should throw an error and forbid the action).
3. Please ensure you've set up the Git hooks described above, and that you've included the relevant Jira ticket ID in your commit message.
4. In the GitHub UI, create a new PR to merge the feature branch into the main branch.
5. After receiving **at least one approving review** (note that the author of the PR must not be the reviewer), merge the PR into main. Ensure that the merging message includes the relevant Jira ticket ID (ex. does not start with 'Merge pull request...').

## Mend Scan

As of `2025-May`, the Mend Unified Agent Daily scan has been removed from all repositories, and now only the Mend Github App scan will run going forward.

The Mend App Scan will run on push when any of the following conditions are met:

- One of the commits added or removed file(s) that have an extension supported by Mend.
- One of the commits includes a modification of the package manager configuration file(s).

Scan Results:

- All scans (Main & PR branches) will show scan results on Github.
- Results will be pushed to the Mend dashboard for main branch scans only.
