Note: This directory name, and the names of the files in this directory, must be
as short as possible.  This is the longest path in an Eclipse install,
and runs into O/S limitations.