package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.carbon.OS;
import org.eclipse.swt.internal.cocoa.Cocoa;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

class FindDialog extends Dialog {

	boolean isOpen;
	int webView;
	Shell dialog;
	Text text;
	Button caseButton;
	Button wrapButton;
	Button previousButton;
	Button nextButton;

	FindDialog(Shell parent, int style) {
		super(parent, style);
		isOpen = false;
		setText("Find");
	}

	FindDialog(Shell parent) {
		this(parent, 0);
	}

	void open(int webView) {
		this.webView = webView;
		if (isOpen) {
			dialog.setActive();
		} else {
			dialog = new Shell(getParent(), SWT.DIALOG_TRIM | SWT.ON_TOP);
			dialog.setText("Find");
			dialog.setLayout(new GridLayout());

			createDialogControls(dialog);

			dialog.addListener(SWT.Close, new Listener() {
				public void handleEvent(Event event) {
					isOpen = false;
					dialog.dispose();
				}
			});

			dialog.setDefaultButton(nextButton);
			dialog.pack();
			Rectangle rect = getParent().getMonitor().getBounds();
			Rectangle bounds = dialog.getBounds();
			dialog.setLocation(rect.x + (rect.width - bounds.width) / 2, rect.y
					+ (rect.height - bounds.height) / 2);
			dialog.setMinimumSize(Math.max(bounds.width, 350), bounds.height);
			dialog.open();
			dialog.setActive();
			isOpen = true;

			Display display = getParent().getDisplay();
			while (!dialog.isDisposed()) {
				if (!display.readAndDispatch())
					display.sleep();
			}
		}
	}

	void close() {
		dialog.close();
	}

	void createDialogControls(Composite parent) {
		GridLayout layout = new GridLayout(2, false);
		layout.verticalSpacing = 0;
		layout.marginHeight = 0;

		Composite textComposite = new Composite(parent, SWT.NONE);
		textComposite.setLayout(layout);
		textComposite.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true,
				false));

		Label label = new Label(textComposite, SWT.NONE);
		label.setText("Find:");
		text = new Text(textComposite, SWT.BORDER);
		text.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));

		Composite checkComposite = new Composite(parent, SWT.NONE);
		checkComposite.setLayout(layout);
		checkComposite.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true,
				false));

		caseButton = new Button(checkComposite, SWT.CHECK);
		caseButton.setText("Case sensitive");
		wrapButton = new Button(checkComposite, SWT.CHECK);
		wrapButton.setText("Wrap search");
		wrapButton.setSelection(true);

		Composite buttonComposite = new Composite(parent, SWT.NONE);
		buttonComposite.setLayout(layout);
		buttonComposite.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, true,
				true));

		Composite buttonClient = new Composite(buttonComposite, SWT.NONE);
		buttonClient.setLayout(layout);

		previousButton = new Button(buttonClient, SWT.PUSH);
		previousButton.setText("Find Previous");
		previousButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				doFind(false);
			}
		});

		nextButton = new Button(buttonClient, SWT.PUSH);
		nextButton.setText("Find Next");
		nextButton.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				doFind(true);
			}
		});
	}

	void doFind(boolean forwardDirection) {
		String str = text.getText();
		int length = str.length();
		char[] chars = new char[length];
		str.getChars(0, length, chars, 0);
		int sHandle = OS.CFStringCreateWithCharacters(0, chars, length);
		int direction = forwardDirection ? 1 : 0;
		int caseSensitive = caseButton.getSelection() ? 1 : 0;
		int wrap = wrapButton.getSelection() ? 1 : 0;
		Cocoa.objc_msgSend(webView,
				Cocoa.S_searchFor_direction_caseSensitive_wrap, sHandle,
				direction, caseSensitive, wrap);
		OS.CFRelease(sHandle);
	}

}
