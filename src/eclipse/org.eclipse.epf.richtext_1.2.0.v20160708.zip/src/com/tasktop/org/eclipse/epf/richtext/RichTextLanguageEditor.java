/*******************************************************************************
 * Copyright (c) 2004, 2016 Tasktop Technologies.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Tasktop EULA
 * which accompanies this distribution, and is available at
 * http://tasktop.com/legal
 *******************************************************************************/

package com.tasktop.org.eclipse.epf.richtext;

import java.util.Set;

import org.eclipse.mylyn.internal.wikitext.html.core.HtmlSubsetLanguage;
import org.eclipse.mylyn.wikitext.core.parser.DocumentBuilder.BlockType;
import org.eclipse.mylyn.wikitext.core.parser.markup.MarkupLanguage;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorSite;

import com.tasktop.org.eclipse.epf.richtext.actions.AddOrderedListAction;
import com.tasktop.org.eclipse.epf.richtext.actions.AddUnorderedListAction;
import com.tasktop.org.eclipse.epf.richtext.actions.IndentAction;
import com.tasktop.org.eclipse.epf.richtext.actions.OutdentAction;

public class RichTextLanguageEditor extends RichTextEditor {

	private final MarkupLanguage language;

	public RichTextLanguageEditor(Composite parent, int style, IEditorSite editorSite, MarkupLanguage language) {
		super(parent, style, editorSite);
		this.language = language;
	}

	@Override
	protected void fillToolBarWithExtendedOperations(IRichTextToolBar toolBar) {
		if (language instanceof HtmlSubsetLanguage) {
			boolean needsSeparator = false;
			Set<BlockType> blockTypes = ((HtmlSubsetLanguage) language).getSupportedBlockTypes();
			if (blockTypes.contains(BlockType.NUMERIC_LIST)) {
				toolBar.addAction(new AddOrderedListAction(this));
				needsSeparator = true;
			}
			if (blockTypes.contains(BlockType.BULLETED_LIST)) {
				toolBar.addAction(new AddUnorderedListAction(this));
				needsSeparator = true;
			}
			if (blockTypes.contains(BlockType.QUOTE)) {
				if (needsSeparator) {
					toolBar.addSeparator();
				}
				toolBar.addAction(new OutdentAction(this));
				toolBar.addAction(new IndentAction(this));
			}
		}
	}

}
