/*******************************************************************************
 * Copyright (c) 2009 Atlassian and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Atlassian - initial API and implementation
 ******************************************************************************/

package com.atlassian.connector.eclipse.internal.jira.core;

import org.apache.commons.lang.ArrayUtils;
import org.eclipse.mylyn.tasks.core.data.TaskAttribute;

import com.atlassian.connector.eclipse.internal.jira.core.model.JiraWorkLog;
import com.tasktop.epl.commons.core.DefaultTasktopTaskSchema;

public class JiraTaskSchema extends DefaultTasktopTaskSchema {

	public static final String ADJUST_ESTIMATE_ATTRIBUTE = "attribute.jira.worklog.adjustEstimate"; //$NON-NLS-1$

	public final Field ADJUST_ESTIMATE_KEY = createField(ADJUST_ESTIMATE_ATTRIBUTE,
			"adjustEstimate", "Adjust Estimate", TaskAttribute.TYPE_SHORT_TEXT); //$NON-NLS-1$ //$NON-NLS-2$

	public static TaskAttribute createWorklogAttribute(int ordinal, String id, String userId, long start,
			long duration, TaskAttribute parent, JiraWorkLog.AdjustEstimateMethod adjustEstimateKey) {
		TaskAttribute attribute = DefaultTasktopTaskSchema.createWorklogAttribute(ordinal, id, userId, start, duration,
				parent);
		if (adjustEstimateKey == null
				|| !ArrayUtils.contains(JiraWorkLog.AdjustEstimateMethod.values(), adjustEstimateKey)) {
			adjustEstimateKey = JiraWorkLog.AdjustEstimateMethod.AUTO;
		}
		attribute.createAttribute(ADJUST_ESTIMATE_ATTRIBUTE).setValue(adjustEstimateKey.toString());

		return attribute;
	}

}
