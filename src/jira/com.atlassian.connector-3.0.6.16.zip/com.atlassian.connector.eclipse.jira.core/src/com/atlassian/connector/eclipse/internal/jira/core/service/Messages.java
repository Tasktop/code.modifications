/*******************************************************************************
 * Copyright (c) 2004, 2008 Tasktop Technologies and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Tasktop Technologies - initial API and implementation
 *******************************************************************************/

package com.atlassian.connector.eclipse.internal.jira.core.service;

import org.eclipse.osgi.util.NLS;

public class Messages {
	private static final String BUNDLE_NAME = "com.atlassian.connector.eclipse.internal.jira.core.service.messages"; //$NON-NLS-1$

	static {
		// load message values from bundle file
		reloadMessages();
	}

	public static void reloadMessages() {
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}

	public static String JiraCaptchaRequiredException_remote_api_locked_login_browser;

	public static String JiraClientCache_Getting_server_information;

	public static String JiraClientCache_Updating_repository_configuration;

	public static String JiraClientCache_getting_issue_types;

	public static String JiraClientCache_getting_priorities;

	public static String JiraClientCache_getting_projects;

	public static String JiraClientCache_getting_resolutions;

	public static String JiraClientCache_getting_statuses;

	public static String JiraClientCache_project_details_for;

	public static String JiraClientCache_getting_project_roles;

	public static String JiraClientCache_getting_configuration;

	public static String JiraClient_attachment_too_large;

	public static String JiraClient_attachment_processing_exception;

	public static String JiraClient_Io_exception;

	public static String JiraClient_Timeworked_entry_missing;

	public static String JiraClient_Uploading_empty_files_is_not_supported;
}
