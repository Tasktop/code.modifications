Updating the SOAP stubs:

1. Run the "JIRA WSDL2Java" launch configuration
2. Run the build-helper.xml ant build
3. Run Source > Format on the src folder
