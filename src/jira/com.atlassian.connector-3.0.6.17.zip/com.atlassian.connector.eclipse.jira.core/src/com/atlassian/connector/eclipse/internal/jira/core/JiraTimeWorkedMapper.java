/*******************************************************************************
 * Copyright (c) 2009 Atlassian and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Atlassian - initial API and implementation
 ******************************************************************************/

package com.atlassian.connector.eclipse.internal.jira.core;

import org.apache.commons.lang.StringUtils;
import org.eclipse.mylyn.tasks.core.data.TaskAttribute;

import com.atlassian.connector.eclipse.internal.jira.core.model.JiraWorkLog.AdjustEstimateMethod;
import com.tasktop.epl.commons.core.DefaultTasktopTaskSchema;
import com.tasktop.epl.commons.core.TimeWorkedMapper;

public class JiraTimeWorkedMapper extends TimeWorkedMapper {
	private final AdjustEstimateMethod adjustEstimate;

	public JiraTimeWorkedMapper(String id, String userId, long start, long duration,
			AdjustEstimateMethod adjustEstimateKey) {
		super(id, userId, start, duration);
		this.adjustEstimate = adjustEstimateKey;
	}

	public static JiraTimeWorkedMapper createFrom(TaskAttribute attribute) {
		TimeWorkedMapper defaultMapper = TimeWorkedMapper.createFrom(attribute);
		AdjustEstimateMethod adjustEstimateMethod = AdjustEstimateMethod.AUTO;
		TaskAttribute adjustEstimateAttribute = attribute.getAttribute(JiraTaskSchema.ADJUST_ESTIMATE_ATTRIBUTE);
		if (adjustEstimateAttribute != null && StringUtils.isNotEmpty(adjustEstimateAttribute.getValue())) {
			try {
				adjustEstimateMethod = AdjustEstimateMethod.fromValue(adjustEstimateAttribute.getValue());
			} catch (IllegalArgumentException e) {
				// Default to AUTO
			}
		}
		return new JiraTimeWorkedMapper(defaultMapper.getId(), defaultMapper.getUserId(), defaultMapper.getStart(),
				defaultMapper.getDuration(), adjustEstimateMethod);
	}

	@Override
	public void applyTo(TaskAttribute attribute) {
		super.applyTo(attribute);
		if (getAdjustEstimate() != null) {
			DefaultTasktopTaskSchema.getField(JiraTaskSchema.ADJUST_ESTIMATE_ATTRIBUTE)
					.createAttribute(attribute)
					.setValue(adjustEstimate.value());
		}
	}

	public AdjustEstimateMethod getAdjustEstimate() {
		return adjustEstimate;
	}

}
